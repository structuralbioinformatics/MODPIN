python parse_seq.py ../example/sequences_Marc_Vidal.fasta /home/boliva/DATABASES/BLAST/uniprot_sprot.fasta ../example/uniprot_Marc_Vidal.fasta

