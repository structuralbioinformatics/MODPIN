python parse_list.py ../example/list_Marc_Vidal  ../example/SNP_LIST/
