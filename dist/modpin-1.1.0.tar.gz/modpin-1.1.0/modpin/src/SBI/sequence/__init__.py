from Sequence 	   import Sequence
from Fasta    	   import Fasta
from SeqAli   	   import SeqAli
from IndexedSeqAli import IndexedSeqAli