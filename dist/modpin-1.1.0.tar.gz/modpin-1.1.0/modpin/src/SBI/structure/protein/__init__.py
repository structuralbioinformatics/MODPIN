from SecondaryStructure import SecondaryStructure
from Arch               import Arch
import SShelper
import Sequencer