from Residue             import Residue
from ResidueOfNucleotide import ResidueOfNucleotide
from ResidueOfAminoAcid  import ResidueOfAminoAcid
