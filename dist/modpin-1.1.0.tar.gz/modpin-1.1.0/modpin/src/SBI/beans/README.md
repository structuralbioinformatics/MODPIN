BEANS
=====

Very basic objects to help build and work on the rest of the module.

**File** allows to better work with file positions, paths, sufixes, etc...

**Path** contains a series of _staticmethods_ to navigate and work in the filesystem

**Executable** will check the availability of external programs and execute them

**StorableObject** adds load/dump, deepcopy and read/write methods to its _derived objects_