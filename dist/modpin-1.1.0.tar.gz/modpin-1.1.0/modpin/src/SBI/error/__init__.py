from FileError   import FileError
from BlastError  import BlastError
from SeqAliError import SeqAliError
