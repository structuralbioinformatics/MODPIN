__all__ = ["DSSPExe", "DSSP"]

from DSSPExe import DSSPExe
from DSSP    import DSSP
