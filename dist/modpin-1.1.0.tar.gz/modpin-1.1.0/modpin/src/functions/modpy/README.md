# MODPY
MODPY is a collection of python scripts for [MODELLER](http://salilab.org/modeller/).  
Each script contains in itself a brief explanation of what they do and their particular requirements and inputs.

